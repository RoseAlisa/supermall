<template>
  <div class="pollution">
    <a href="https://act.mogujie.com/ZZ1x67"><img src="~@/assets/img/home/recommend_bg.jpg" alt="这是带有链接的图片"></a>
  </div>
</template>

<script>
export default {
  name: "HomeFeature"
}
</script>

<style scoped>
.pollution img {
  width:100%;
}
</style>
