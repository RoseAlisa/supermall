export default {
  CartLength(state){
    return state.cartlist.length
  },
  CartList(state) {
    return state.cartlist
  },
}
